<?php
 echo "輸入的姓名為：";
 echo $_POST["username"];
?>