<?php
	echo $_GET["items"];
?>