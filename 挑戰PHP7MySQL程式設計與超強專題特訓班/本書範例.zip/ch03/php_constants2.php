<?php
	echo "目前系統的 PHP 版本為：";
	echo PHP_VERSION;
?>