<?php
	function add($num1, $num2){
		$result = $num1 + $num2;
		return $result;
	}	//執行加法
?>