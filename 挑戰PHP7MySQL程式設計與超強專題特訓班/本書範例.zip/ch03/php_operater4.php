<?php
	$a = 3; $b = 5;
	$a += $b;
	echo $a;
?>