<?php
	function minus($num1, $num2){
		$result = $num1 - $num2;
		return $result;
	}	//�����k
?>