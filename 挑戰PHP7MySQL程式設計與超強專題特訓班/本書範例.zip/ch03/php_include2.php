<?php
	echo "載入前...";
	include "inc3.php";
	echo "載入後...";
?>