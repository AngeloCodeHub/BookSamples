<?php
	echo "目前網頁的虛擬路徑為：";
	echo $_SERVER['PHP_SELF'];
?>