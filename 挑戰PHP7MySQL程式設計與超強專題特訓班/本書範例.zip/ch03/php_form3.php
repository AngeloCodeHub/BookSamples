<?php
	foreach($_GET["items"] as $Value){	//將陣列中每個值放置到 $Value
		echo $Value."<br />";
}
?>