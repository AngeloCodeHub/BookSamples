<?PHP
	echo '我是一個字串';
?> 

