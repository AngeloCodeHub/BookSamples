<?php
	$a = 5; $a++;
	echo '$a = '. $a .'<br />';
	$b = 6; $b--;
	echo '$b = '. $b;	
?>