<?php
	echo "目前執行檔案的路徑為：";
	echo __FILE__;
?>