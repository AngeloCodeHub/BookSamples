<?php
	define('eHappy',"文淵閣工作室");
	const eHappyUrl = "http://www.e-happy.com.tw";
	echo "您好，歡迎光臨".eHappy."的網站<br>";
	echo "網址為：".eHappyUrl;
?>