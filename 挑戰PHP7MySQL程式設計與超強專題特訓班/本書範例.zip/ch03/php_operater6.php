<?php
	echo '$a = 1<br />';
	$a = 1;
	echo '$a++ = '.$a++.'<br />';
	$a = 1;
	echo '++$a = '.++$a;
?>