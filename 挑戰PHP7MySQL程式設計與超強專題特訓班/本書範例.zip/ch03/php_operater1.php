<?php
	$a = "我最喜歡的程式是：";
	$b = "PHP";
	echo $a . $b;
?> 
