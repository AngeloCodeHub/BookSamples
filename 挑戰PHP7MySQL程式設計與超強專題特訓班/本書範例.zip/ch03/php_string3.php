<?PHP 
	echo 'PHP 的安裝路徑在 C:\\PHP\\ 中。'; 
?>
