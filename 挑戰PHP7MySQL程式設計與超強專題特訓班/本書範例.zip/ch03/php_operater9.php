<?php
	$fp = @fopen ("test.txt");
?> 
