<?php
	include "inc1.php";
	echo "5+3=".add(5,3)."<br />";
	require "inc2.php";
	echo "5-3=".minus(5,3);
?>