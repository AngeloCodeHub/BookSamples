<?PHP 
	echo 'How are you? I\'m fine, thank you.'; 
?> 
