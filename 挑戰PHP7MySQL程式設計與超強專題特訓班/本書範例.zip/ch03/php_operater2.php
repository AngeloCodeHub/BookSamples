<?php
	$a = 5;
	$b = $a + 5;
	echo $b;
?>