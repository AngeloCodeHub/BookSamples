<?php 
	$myLanguage = "PHP"; 
	echo '我最喜愛的網頁程式是 $myLanguage <br />'; 
	echo "我最喜愛的網頁程式是 $myLanguage"; 
?> 
