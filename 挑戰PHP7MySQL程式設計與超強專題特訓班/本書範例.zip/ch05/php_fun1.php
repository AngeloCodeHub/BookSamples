<?php
	function myInformation(){
		echo "歡迎光臨文淵閣工作室！";
	}
	myInformation();
?>
	