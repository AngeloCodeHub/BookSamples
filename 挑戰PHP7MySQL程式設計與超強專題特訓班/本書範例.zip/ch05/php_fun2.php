<?php
	function showName($myName){
		echo "大家好，我的名字叫：" . $myName . "。<br />";
	}
	showName("David");
	showName("Lily");
?>
	