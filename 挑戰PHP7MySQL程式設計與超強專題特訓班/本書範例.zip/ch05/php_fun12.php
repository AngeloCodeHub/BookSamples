<?php
	echo strnatcmp("str20", "str5");
?>