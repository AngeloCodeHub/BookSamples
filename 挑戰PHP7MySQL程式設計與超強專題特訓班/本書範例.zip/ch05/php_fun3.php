<?php
	function sumNum($num1=0, $num2=0){
		echo "$num1 + $num2 = ";
		echo $num1+$num2 . "<br />";
	}
	sumNum();
	sumNum(1);
	sumNum(5, 6);
?>