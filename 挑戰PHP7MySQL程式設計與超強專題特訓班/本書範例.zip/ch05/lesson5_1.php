<?php
$x = 10;
$circle = pow(($x / 2), 2) * M_PI;
echo round($circle,2);
?>