<?php 
	header("Content-Type: text/html; charset=utf-8");
	include("connMysql.php");
	$seldb = @mysqli_select_db($db_link, "class");
	if (!$seldb) die("資料庫選擇失敗！");
	$sql_query = "SELECT * FROM students";
	$result = mysqli_query($db_link, $sql_query);	
	while($row_result=mysqli_fetch_array($result)){
		foreach($row_result as $item=>$value){
			echo $item."=".$value."<br />";
		}
		echo "<hr />";
	}
?>