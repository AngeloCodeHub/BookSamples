<?php
	$a=5;
	if($a > 0) echo '$a 變數的值是正數';
?>