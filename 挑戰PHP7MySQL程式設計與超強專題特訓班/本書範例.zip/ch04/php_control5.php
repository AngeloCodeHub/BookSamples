<?php
	$i = 0;
	while ($i<10){
		$i++;
		echo $i."&nbsp;"; // &nbsp; 為空白字元		
	}
?>