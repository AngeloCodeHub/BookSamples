<?php
	$i = 0;
	do{
		$i++;
		echo $i."&nbsp;"; // &nbsp; 為空白字元		
	}while ($i<10)
?>