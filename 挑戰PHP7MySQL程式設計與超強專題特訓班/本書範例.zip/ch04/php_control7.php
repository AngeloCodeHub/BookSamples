<?php
	$countI = 0;
	for ($i=1;$i<=10;$i++){
		$countI += $i;
	}
	echo $countI;
?>