<?php
	$str1 = "string1";
	$str2 = "string2";
	echo strcmp($str1,$str2);
?>