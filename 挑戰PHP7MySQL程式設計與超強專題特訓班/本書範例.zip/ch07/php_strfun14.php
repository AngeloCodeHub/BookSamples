<?php
$name = "黃沛然";
$age = "3";
$height = "95";
$weight = "14"; 
$person = sprintf ("大家好，我是%s ，我今年%d歲，身高 %d公分，體重%d公斤。", $name, $age, $height, $weight);
echo $person;
?>