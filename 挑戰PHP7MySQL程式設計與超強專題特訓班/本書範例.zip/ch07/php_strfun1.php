<?php
	$showStr="你學PHP\n我學PHP\n大家來學PHP";
	echo $showStr."<br>";
	echo nl2br($showStr);
?>