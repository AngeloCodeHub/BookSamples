<?php
$showStr = array("忠","孝","仁","愛","信","義","和","平");
echo implode(" ",$showStr);
?>