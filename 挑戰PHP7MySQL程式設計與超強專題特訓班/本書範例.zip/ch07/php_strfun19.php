<?php
	$showStr="大家來學 <font color='blue'>PHP & MySQL</font>";
	echo $showStr."<br>";
	echo htmlspecialchars($showStr);
?>