<?php
$dollar = array("1", "0.0322", "0.0210", "3.5252");
vprintf("今日匯率:% 5.4f台幣(NTD) = % 5.4f美元(USD) = % 5.4f歐元(EUR) = % 5.4f日元(YEN)", $dollar);
?>