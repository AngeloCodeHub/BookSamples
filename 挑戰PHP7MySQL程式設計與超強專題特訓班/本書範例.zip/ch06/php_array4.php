<?php
$myArray = array('myName'=>'David', 'myHeight'=>181, 'myWeight'=>78);
echo "大家好，我的名字叫".$myArray['myName']."。我的身高".$myArray['myHeight']."公分，體重".$myArray['myWeight']."公斤。";
?>