<?php
$weekArray = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
for($i=0;$i<7;$i++){
	echo $weekArray[$i] . "<br />";
}
?>