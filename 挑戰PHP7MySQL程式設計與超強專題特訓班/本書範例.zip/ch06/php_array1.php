<?php
$weekArray[] = 'Sunday';
$weekArray[] = 'Monday';
$weekArray[] = 'Tuesday';
$weekArray[] = 'Wednesday';
$weekArray[] = 'Thursday';
$weekArray[] = 'Friday';
$weekArray[] = 'Saturday';
for($i=0;$i<7;$i++){
	echo $weekArray[$i] . "<br />";
}
?>