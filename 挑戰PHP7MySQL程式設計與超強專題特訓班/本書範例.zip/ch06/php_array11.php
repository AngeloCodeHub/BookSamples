<?php
$testArray = array("甲","乙","丙");
echo "print_r() 的結果：";
print_r($testArray);
echo "<br />var_dump() 的結果：";
var_dump($testArray);
echo "<br />var_export() 的結果：";
var_export($testArray);
?>