<?php
	echo "目前檔案所在的路徑為：".realpath(".")."<br />";
	echo "完整的檔案路徑為:".__FILE__."<br />";
	echo "資料夾為：".__DIR__."<br />";
	echo "檔名為：".basename(__FILE__)."<br />";
?>
