<?php
$contents = file_get_contents('php_file11.htm');
echo strip_tags($contents);
?>